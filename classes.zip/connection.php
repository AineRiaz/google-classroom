<?php 
$servername="localhost";
$username="root";
$password="";
$dbname="announcements_db";

$conn=mysqli_connect($servername,$username,$password,$dbname);
if($conn){
  echo "connected successfuly";
}